package nro.core.util;

/**
 *
 * @author Anwin
 */
public enum FormatStyle {
    
    VIETNAMESE,
    KMB
    
}





