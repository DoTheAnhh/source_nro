package nro.entity.npc.list;

/**
 * @author Anwin
 */

public class Rong6Sao extends Rong1Sao {

    public Rong6Sao(int mapId, int status, int cx, int cy, int tempId, int avartar) {
        super(mapId, status, cx, cy, tempId, avartar);
    }

}






