package nro.entity.boss.map.yardart;

/*
 * @Author: Anwin
 */

import nro.entity.boss.BossID;
import static nro.entity.boss.BossType.YARDART;
import nro.entity.boss.BossesData;

public class ChienBinh1 extends Yardart {

    public ChienBinh1() throws Exception {
        super(YARDART, BossID.CHIEN_BINH_1, BossesData.CHIEN_BINH_1);
    }

    @Override
    protected void init() {
        x = 376;
        x2 = 446;
        y = 456;
        y2 = 456;
        range = 1000;
        range2 = 150;
        timeHoiHP = 20000;
        rewardRatio = 3;
    }
}






