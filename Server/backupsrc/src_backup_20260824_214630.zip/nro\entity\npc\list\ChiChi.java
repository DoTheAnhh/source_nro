package nro.entity.npc.list;

/**
 * @author Anwin
 */

import nro.service.inventory.InventoryService;
import nro.server.ServerManager;
import nro.service.Service;
import nro.core.util.FormatStyle;
import nro.core.util.Util;
import nro.core.consts.ConstAttribute;
import nro.core.consts.ConstNpc;
import java.util.ArrayList;
import java.util.List;
import nro.repository.dao.EventDAO;
import nro.entity.item.Item;
import nro.service.item.ItemService;
import nro.entity.attribute.Attribute;
import nro.entity.npc.Npc;
import nro.entity.player.Player;

public class ChiChi extends Npc {

    public ChiChi(int mapId, int status, int cx, int cy, int tempId, int avartar) {
        super(mapId, status, cx, cy, tempId, avartar);
    }
    
    int TIME_12_HOUS = 43200;
    int TIME_24_HOUS = 86400;
    int TIME_36_HOUS = 129600;
    int TIME_48_HOUS = 172800;
    int TIME_60_HOUS = 216000;
    
    private void applyGlobalExpBuff(Attribute at, int point) {
        int rewardStage = 0;
        int value = 0;
        int time = 0;

        if (point >= 5000) {
            rewardStage = 5;
            value = 400;
            time = TIME_60_HOUS;
        } else if (point >= 1500) {
            rewardStage = 4;
            value = 300;
            time = TIME_48_HOUS;
        } else if (point >= 500) {
            rewardStage = 3;
            value = 200;
            time = TIME_36_HOUS;
        } else if (point >= 200) {
            rewardStage = 2;
            value = 100;
            time = TIME_24_HOUS;
        } else if (point >= 100) {
            rewardStage = 1;
            value = 100;
            time = TIME_12_HOUS;
        }

        // Chỉ kích hoạt nếu vượt mốc mới
        if (rewardStage > EventDAO.getLAST_EXP_REWARD_STAGE_INTERNATIONAL_WOMENS_DAY()) {
            EventDAO.setLAST_EXP_REWARD_STAGE_INTERNATIONAL_WOMENS_DAY(rewardStage);
            at.setValue(value);
            at.setTime(time);
        }
    }

    @Override
    public void openBaseMenu(Player player) {
        if (canOpenNpc(player)) {
            Item BongHoaHong = InventoryService.gI().findItemBag(player, 1530);
            List<String> menuList = new ArrayList<>();

            menuList.add("Cửa Hàng");
        



            menuList.add("Đóng");

            String[] menus = menuList.toArray(String[]::new);
            this.createOtherMenu(player, ConstNpc.BASE_MENU, "Bạn muốn hỏi chi ?", menus);
        }
    }

    @Override
    public void confirmMenu(Player player, int select) {
        if (canOpenNpc(player)) {
            if (player.iDMark.isBaseMenu()) {
                switch (select) {
                    case 0:
                        //Shop
                        break;
                    case 1:
                        break;
                    default:
                        break;
                }
            

            }
        }
    }
    

}
