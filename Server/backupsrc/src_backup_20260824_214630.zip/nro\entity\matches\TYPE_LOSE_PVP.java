package nro.entity.matches;


//DEV Anwin

public enum TYPE_LOSE_PVP {

    RUNS_AWAY,
    DEAD

}





