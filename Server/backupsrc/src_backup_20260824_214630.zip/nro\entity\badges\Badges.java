package nro.entity.badges;


/*
 * Author Dev By Anwin
 */

public class Badges {

    public int idBadges = -1;
    public long lastTimeSendBadges;

}




