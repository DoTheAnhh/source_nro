package nro.entity.template;

/**
 *
 * @author Anwin
 */
public class BgItem {
    
    public int id;

    public short idImage;

    public short dx;

    public short dy;

    public byte layer;
    
}






