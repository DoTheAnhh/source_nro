package nro.entity.boss;

/**
 *
 * @author Anwin
 */
public enum TypeEventBoss {
    
    LUNAR_NEW_YEAR,
    CHRISTMAS,
    VULAN,
    HALLOWEEN,
    TRUNG_THU
    
}





