package nro.entity.template;

/**
 *
 * @author Anwin
 */
public class AchievementQuest {
    
    public long completed;
    public boolean isRecieve;

    public AchievementQuest(long completed, boolean isRecieve) {
        this.completed = completed;
        this.isRecieve = isRecieve;
    }
        
}






