package nro.entity.template;

/**
 *
 * @author Anwin
 */
public class FlagBag {
    
    public int id;
    public short iconId;
    public short[] iconEffect;
    public String name;
    public int gold;
    public int gem;
}






