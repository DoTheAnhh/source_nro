package nro.entity.npc;

import nro.entity.player.Player;

/**
 *
 *@Stole By Anwin
 *
 */

public interface IAtionNpc {
    
    void openBaseMenu(Player player);

    void confirmMenu(Player player, int select);


}






