package nro.entity.boss.anwredribbonhq;

/*
 * @Author: Anwin
 */

import nro.service.effect.EffectSkillService;
import nro.entity.player.Player;
import nro.entity.boss.Boss;
import nro.entity.boss.BossData;
import nro.entity.boss.BossStatus;
import static nro.entity.boss.BossType.PHOBANDT;
import nro.service.boss.RedRibbonHQManager;
import nro.service.fun.ChangeMapService;
import nro.service.Service;
import nro.entity.skill.Skill;
import nro.core.util.Util;
import nro.core.consts.ConstPlayer;
import nro.entity.map.ItemMap;
import nro.entity.map.Zone;

public class NinjaClone extends Boss {

    private Boss boss;

    public NinjaClone(Zone zone, Boss boss, long dame, long hp, int id) throws Exception {
        super(PHOBANDT, id, new BossData(
                "Ninja Áo Tím",
                ConstPlayer.TRAI_DAT,
                new short[]{123, 124, 125, -1, -1, -1},
                dame,
                new long[]{hp},
                new int[]{54},
                new int[][]{
                    {Skill.DRAGON, 1, 1000},
                    {Skill.KAMEJOKO, 7, 2000}
                },
                new String[]{},
                new String[]{
                    "|-1|Ta sẽ xé xác ngươi ra thành trăm mảnh",
                    "|-1|Ha ha ha"
                },
                new String[]{},
                60
        ));

        this.zone = zone;
        this.boss = boss;
    }

    @Override
    public void reward(Player plKill) {
        if (plKill != null && Util.isTrue(100, 100)) {
            ItemMap it = new ItemMap(
                    this.zone,
                    Util.nextInt(16, 20),
                    1,
                    this.location.x,
                    this.zone.map.yPhysicInTop(this.location.x, this.location.y - 24),
                    plKill.id
            );
        }
    }

    @Override
    public void joinMap() {
        if (this.boss != null && this.boss.location != null) {
            ChangeMapService.gI().changeMap(
                    this,
                    this.zone,
                    this.boss.location.x + Util.nextInt(-200, 200),
                    this.boss.location.y
            );
        } else {
            ChangeMapService.gI().changeMap(this, this.zone, 190, 312);
        }

        this.changeStatus(BossStatus.CHAT_S);
    }

    @Override
    public synchronized double injured(Player plAtt, double damage, boolean piercing, boolean isMobAttack) {
        if (!this.isDie()) {
            if (!piercing && Util.isTrue(20, 100)) {
                this.chat("Xí hụt");
                return 0;
            }

            damage = this.nPoint.subDameInjureWithDeff(damage);

            if (!piercing && effectSkill.isShielding) {
                if (damage > nPoint.hpMax) {
                    EffectSkillService.gI().breakShield(this);
                }
                damage = 1;
            }

            this.nPoint.subHP(damage);

            if (isDie()) {
                this.setDie(plAtt);
                die(plAtt);
            }

            return damage;
        } else {
            return 0;
        }
    }

    @Override
    public void die(Player plKill) {
        if (plKill != null) {
            reward(plKill);
        }

        this.changeStatus(BossStatus.DIE);
    }

    @Override
    public void leaveMap() {
        ChangeMapService.gI().exitMap(this);
        this.lastZone = null;
        this.boss = null;
        this.lastTimeRest = System.currentTimeMillis();
        this.changeStatus(BossStatus.REST);
        RedRibbonHQManager.gI().removeBoss(this);
        this.dispose();
    }
}