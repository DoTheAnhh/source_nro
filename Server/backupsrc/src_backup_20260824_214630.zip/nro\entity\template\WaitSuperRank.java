package nro.entity.template;

/**
 *
 * @author Anwin
 */
public class WaitSuperRank {
    
    public long playerId;
    public long rivalId;

    public WaitSuperRank(long playerId, long rivalId) {
        this.playerId = playerId;
        this.rivalId = rivalId;
    }
        
}






