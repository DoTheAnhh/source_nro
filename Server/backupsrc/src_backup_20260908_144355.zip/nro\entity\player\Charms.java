package nro.entity.player;

import org.json.simple.JSONArray;

public class Charms {

    /**
     * Bảy lá bùa cơ bản, theo đúng id vật phẩm.
     *
     * <p>Trí tuệ, Mạnh mẽ, Da trâu, Oai hùng, Bất tử, Dẻo dai, Thu hút.</p>
     */
    public static final int[] BUA_CO_BAN = {213, 214, 215, 216, 217, 218, 219};

    /**
     * Ba lá bùa đệ tử nằm trong gói vĩnh viễn: Bùa Đệ Tử, x2, x3.
     *
     * <p><b>Chúng CỘNG DỒN, không phải lấy cái cao nhất.</b>
     * {@code NPoint.calPoint} xét từng lá một và cộng thêm vào tiềm năng của đệ
     * tử: lá gốc {@code +2}, x2 thêm {@code +3}, x3 thêm {@code +4}. Mang cả ba
     * là <b>+9 lần</b> tiềm năng, không phải +4.</p>
     *
     * <p>Năm lá còn lại (x4, x5, x7, x10, x20 — id 1736..1740) <b>cố ý</b> không
     * có ở đây. Cộng nốt là +35 lần, vĩnh viễn.</p>
     */
    public static final int[] BUA_DE_TU_VINH_VIEN = {522, 1734, 1735};

    /**
     * Trọn gói "Bùa (vĩnh viễn)" Bà Hạt Mít bán: bảy lá cơ bản + ba lá đệ tử.
     *
     * <p>Một mảng duy nhất cho cả ba việc — bán, kiểm tra đã có đủ chưa, và
     * liệt kê ra màn hình. Ba chỗ đọc chung một danh sách thì không thể lệch
     * nhau kiểu "bán bảy lá mà kiểm tra mười lá" rồi mua mãi không xong.</p>
     */
    public static final int[] GOI_VINH_VIEN = {
        213, 214, 215, 216, 217, 218, 219, // bùa cơ bản
        522, 1734, 1735                    // bùa đệ tử, x2, x3
    };

    /**
     * Mốc thời gian coi là "vĩnh viễn": 00:00 ngày 01/01/2100 (giờ UTC).
     *
     * <h2>Vì sao là một con số cụ thể chứ không phải {@code Long.MAX_VALUE}</h2>
     *
     * <p>Mọi chỗ dùng bùa đều chỉ so {@code td > System.currentTimeMillis()},
     * nên {@code Long.MAX_VALUE} chạy đúng — trừ MỘT chỗ:
     * {@code ShopService.resolveShopBua} lấy hiệu {@code (td - bây giờ) / 60000}
     * rồi <b>ép về {@code int}</b> để gửi cho client. Với
     * {@code Long.MAX_VALUE} thì hiệu đó vào khoảng 1,5·10^14 phút, tràn
     * {@code int} và cửa hàng hiện ra một con số âm vô nghĩa.</p>
     *
     * <p>Mốc 2100 cho ra khoảng 26.000 ngày — vẫn là vĩnh viễn với bất kỳ ai
     * chơi game này, mà nằm gọn trong {@code int}.</p>
     *
     * <p>Đây cũng là dấu hiệu để nhận ra bùa vĩnh viễn: {@code td} bằng đúng
     * mốc này. Bùa mua theo giờ không bao giờ chạm tới đó.</p>
     */
    public static final long MOC_VINH_VIEN = 4102444800000L;

    // Các buff bùa cơ bản
    public long tdTriTue;
    public long tdManhMe;
    public long tdDaTrau;
    public long tdOaiHung;
    public long tdBatTu;
    public long tdDeoDai;
    public long tdThuHut;

    // Các buff đệ tử
    public long tdDeTu;
    public long tdDeTu2;
    public long tdDeTu3;
    public long tdDeTu4;
    public long tdDeTu5;
    public long tdDeTu7;
    public long tdDeTu10;
    public long tdDeTu20;

    // Buff trí tuệ nâng cao
    public long tdTriTue3;
    public long tdTriTue4;
    public long tdTriTue5;
    public long tdTriTue7;
    public long tdTriTue10;
    public long tdTriTue20;
    public long lastTimeSubMinTriTueX4;

    // Buff clan
    public long tdDaTrauClan;
    public long tdManhMeClan;
    public long tdTriTueClan;

    // ============================ ADD TIME ============================
    public void addTimeCharms(int itemId, int min) {
        switch (itemId) {
            case 213:
                tdTriTue = Math.max(tdTriTue, System.currentTimeMillis());
                tdTriTue += min * 60 * 1000L;
                break;
            case 214:
                tdManhMe = Math.max(tdManhMe, System.currentTimeMillis());
                tdManhMe += min * 60 * 1000L;
                break;
            case 215:
                tdDaTrau = Math.max(tdDaTrau, System.currentTimeMillis());
                tdDaTrau += min * 60 * 1000L;
                break;
            case 216:
                tdOaiHung = Math.max(tdOaiHung, System.currentTimeMillis());
                tdOaiHung += min * 60 * 1000L;
                break;
            case 217:
                tdBatTu = Math.max(tdBatTu, System.currentTimeMillis());
                tdBatTu += min * 60 * 1000L;
                break;
            case 218:
                tdDeoDai = Math.max(tdDeoDai, System.currentTimeMillis());
                tdDeoDai += min * 60 * 1000L;
                break;
            case 219:
                tdThuHut = Math.max(tdThuHut, System.currentTimeMillis());
                tdThuHut += min * 60 * 1000L;
                break;
            case 522:
                tdDeTu = Math.max(tdDeTu, System.currentTimeMillis());
                tdDeTu += min * 60 * 1000L;
                break;
            case 671:
                tdTriTue3 = Math.max(tdTriTue3, System.currentTimeMillis());
                tdTriTue3 += min * 60 * 1000L;
                break;
            case 672:
                tdTriTue4 = Math.max(tdTriTue4, System.currentTimeMillis());
                tdTriTue4 += min * 60 * 1000L;
                break;
            case 1734:
                tdDeTu2 = Math.max(tdDeTu2, System.currentTimeMillis());
                tdDeTu2 += min * 60 * 1000L;
                break;
            case 1735:
                tdDeTu3 = Math.max(tdDeTu3, System.currentTimeMillis());
                tdDeTu3 += min * 60 * 1000L;
                break;
            case 1736:
                tdDeTu4 = Math.max(tdDeTu4, System.currentTimeMillis());
                tdDeTu4 += min * 60 * 1000L;
                break;
            case 1737:
                tdDeTu5 = Math.max(tdDeTu5, System.currentTimeMillis());
                tdDeTu5 += min * 60 * 1000L;
                break;
            case 1738:
                tdDeTu7 = Math.max(tdDeTu7, System.currentTimeMillis());
                tdDeTu7 += min * 60 * 1000L;
                break;
            case 1739:
                tdDeTu10 = Math.max(tdDeTu10, System.currentTimeMillis());
                tdDeTu10 += min * 60 * 1000L;
                break;
            case 1740:
                tdDeTu20 = Math.max(tdDeTu20, System.currentTimeMillis());
                tdDeTu20 += min * 60 * 1000L;
                break;
            case 1741:
                tdTriTue5 = Math.max(tdTriTue5, System.currentTimeMillis());
                tdTriTue5 += min * 60 * 1000L;
                break;
            case 1742:
                tdTriTue7 = Math.max(tdTriTue7, System.currentTimeMillis());
                tdTriTue7 += min * 60 * 1000L;
                break;
            case 1743:
                tdTriTue10 = Math.max(tdTriTue10, System.currentTimeMillis());
                tdTriTue10 += min * 60 * 1000L;
                break;
            case 1744:
                tdTriTue20 = Math.max(tdTriTue20, System.currentTimeMillis());
                tdTriTue20 += min * 60 * 1000L;
                break;
            case 797:
                tdTriTueClan = Math.max(tdTriTueClan, System.currentTimeMillis());
                tdTriTueClan += min * 60 * 1000L;
                break;
            case 798:
                tdManhMeClan = Math.max(tdManhMeClan, System.currentTimeMillis());
                tdManhMeClan += min * 60 * 1000L;
                break;
            case 799:
                tdDaTrauClan = Math.max(tdDaTrauClan, System.currentTimeMillis());
                tdDaTrauClan += min * 60 * 1000L;
                break;
            case 1950: // item reset toàn bộ bùa
                resetAllCharms();
                break;
        }
    }

    // ============================ RESET ============================
    public void resetAllCharms() {
        tdTriTue = tdManhMe = tdDaTrau = tdOaiHung = tdBatTu = tdDeoDai = tdThuHut = 0;
        tdDeTu = tdDeTu2 = tdDeTu3 = tdDeTu4 = tdDeTu5 = tdDeTu7 = tdDeTu10 = tdDeTu20 = 0;
        tdTriTue3 = tdTriTue4 = tdTriTue5 = tdTriTue7 = tdTriTue10 = tdTriTue20 = 0;
        lastTimeSubMinTriTueX4 = 0;
        tdDaTrauClan = tdManhMeClan = tdTriTueClan = 0;
    }

    // ============================ BÙA VĨNH VIỄN ============================

    /**
     * Hạn của một lá bùa trong gói vĩnh viễn, theo id vật phẩm.
     *
     * <p>Có để nơi khác đọc được hạn bùa mà không phải chép lại bảng
     * "id nào ứng với ô nào" — bảng đó đã có hai bản trong mã
     * ({@link #addTimeCharms} và {@code ShopService.resolveShopBua}), thêm bản
     * thứ ba nữa là chắc chắn có ngày ba bản lệch nhau.</p>
     *
     * @return mốc hết hạn tính bằng mili giây, {@code 0} nếu id không nằm trong
     *         {@link #GOI_VINH_VIEN}
     */
    public long thoiHan(int itemId) {
        switch (itemId) {
            case 213: return tdTriTue;
            case 214: return tdManhMe;
            case 215: return tdDaTrau;
            case 216: return tdOaiHung;
            case 217: return tdBatTu;
            case 218: return tdDeoDai;
            case 219: return tdThuHut;
            case 522: return tdDeTu;
            case 1734: return tdDeTu2;
            case 1735: return tdDeTu3;
            default: return 0;
        }
    }

    /**
     * Đặt trọn gói {@link #GOI_VINH_VIEN} thành vĩnh viễn.
     *
     * <p>Gán thẳng {@link #MOC_VINH_VIEN} chứ không cộng dồn: người đang còn hai
     * ngày bùa Trí tuệ mà mua vĩnh viễn thì thành vĩnh viễn, không phải
     * "vĩnh viễn cộng thêm hai ngày" — cộng vào một mốc đã ở năm 2100 thì cũng
     * chẳng khác gì, nhưng lúc đó {@code td} không còn bằng đúng mốc nữa và
     * {@link #laVinhVien} sẽ không nhận ra.</p>
     */
    public void datVinhVienGoiBua() {
        tdTriTue = tdManhMe = tdDaTrau = tdOaiHung = tdBatTu = tdDeoDai = tdThuHut = MOC_VINH_VIEN;
        tdDeTu = tdDeTu2 = tdDeTu3 = MOC_VINH_VIEN;
    }

    /** Một mốc hạn có phải là bùa vĩnh viễn không. */
    public static boolean laVinhVien(long thoiHan) {
        return thoiHan >= MOC_VINH_VIEN;
    }

    /** Đã có đủ trọn gói ở mức vĩnh viễn chưa. */
    public boolean daDuBuaVinhVien() {
        for (int id : GOI_VINH_VIEN) {
            if (!laVinhVien(thoiHan(id))) {
                return false;
            }
        }
        return true;
    }

    // ============================ JSON SAVE ============================
    public JSONArray toJSONArray() {
        JSONArray arr = new JSONArray();
        arr.add(tdTriTue);
        arr.add(tdManhMe);
        arr.add(tdDaTrau);
        arr.add(tdOaiHung);
        arr.add(tdBatTu);
        arr.add(tdDeoDai);
        arr.add(tdThuHut);
        arr.add(tdDeTu);
        arr.add(tdTriTue3);
        arr.add(tdTriTue4);
        arr.add(tdDeTu2);
        arr.add(tdDeTu3);
        arr.add(tdDeTu4);
        arr.add(tdDeTu5);
        arr.add(tdDeTu7);
        arr.add(tdDeTu10);
        arr.add(tdDeTu20);
        arr.add(tdTriTue5);
        arr.add(tdTriTue7);
        arr.add(tdTriTue10);
        arr.add(tdTriTue20);
        return arr;
    }

    public void loadFromJSONArray(JSONArray arr) {
        if (arr == null || arr.isEmpty()) return;
        tdTriTue = Long.parseLong(String.valueOf(arr.get(0)));
        tdManhMe = Long.parseLong(String.valueOf(arr.get(1)));
        tdDaTrau = Long.parseLong(String.valueOf(arr.get(2)));
        tdOaiHung = Long.parseLong(String.valueOf(arr.get(3)));
        tdBatTu = Long.parseLong(String.valueOf(arr.get(4)));
        tdDeoDai = Long.parseLong(String.valueOf(arr.get(5)));
        tdThuHut = Long.parseLong(String.valueOf(arr.get(6)));
        tdDeTu = Long.parseLong(String.valueOf(arr.get(7)));
        tdTriTue3 = Long.parseLong(String.valueOf(arr.get(8)));
        tdTriTue4 = Long.parseLong(String.valueOf(arr.get(9)));
        tdDeTu2 = Long.parseLong(String.valueOf(arr.get(10)));
        tdDeTu3 = Long.parseLong(String.valueOf(arr.get(11)));
        tdDeTu4 = Long.parseLong(String.valueOf(arr.get(12)));
        tdDeTu5 = Long.parseLong(String.valueOf(arr.get(13)));
        tdDeTu7 = Long.parseLong(String.valueOf(arr.get(14)));
        tdDeTu10 = Long.parseLong(String.valueOf(arr.get(15)));
        tdDeTu20 = Long.parseLong(String.valueOf(arr.get(16)));
        tdTriTue5 = Long.parseLong(String.valueOf(arr.get(17)));
        tdTriTue7 = Long.parseLong(String.valueOf(arr.get(18)));
        tdTriTue10 = Long.parseLong(String.valueOf(arr.get(19)));
        tdTriTue20 = Long.parseLong(String.valueOf(arr.get(20)));
    }

    public void dispose() {
         // clear khi cần
    }
}





