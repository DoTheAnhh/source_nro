package nro.entity.npc.list;

/**
 * @author DoTheAnh
 */
import nro.service.inventory.InventoryService;
import nro.service.fun.ChangeMapService;
import nro.service.Service;
import nro.core.util.FormatStyle;
import nro.core.util.Util;
import nro.core.consts.ConstDailyGift;
import nro.core.consts.ConstMenu;
import nro.core.consts.ConstNpc;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import nro.entity.item.Item;
import nro.service.item.ItemService;
import nro.service.combine.CombineService;
import nro.entity.combine.list.CheTaoCuonSachCu;
import nro.entity.combine.list.DoiSachTuyetKy;
import nro.entity.combine.list.NangCapVatPham;
import nro.entity.combine.list.NhapNgocRong;
import nro.entity.map.deathoralivearena.DeathOrAliveArena;
import nro.service.map.deathoralivearena.DeathOrAliveArenaManager;
import nro.service.map.deathoralivearena.DeathOrAliveArenaService;
import nro.entity.npc.Npc;
import nro.service.player.dailygift.DailyGiftService;
import nro.entity.player.Charms;
import nro.entity.player.Player;
import nro.repository.dao.ConfigDAO;
import nro.service.shop.ShopService;

public class BaHatMit extends Npc {

    /**
     * Số Thỏi vàng phải trả mỗi lần hoá giải (xoá) bùa.
     *
     * <p>Thỏi vàng ở đây là <b>vật phẩm trong hành trang</b> (id 457), không
     * phải cột {@code thoi_vang} của tài khoản — xem
     * {@code ShopService.truThoiVang}.</p>
     *
     * <p>Có giá là để việc xoá không thành thói quen bấm bừa: bùa vĩnh viễn mua
     * bằng tiền thật, xoá nhầm là mất hẳn.</p>
     */
    private static final int GIA_HOA_GIAI_BUA = 1;

    public BaHatMit(int mapId, int status, int cx, int cy, int tempId, int avartar) {
        super(mapId, status, cx, cy, tempId, avartar);
    }

    @Override
    public void openBaseMenu(Player player) {
        if (canOpenNpc(player)) {
            switch (this.mapId) {
                case 5:
                    List<String> menuOptions = new ArrayList<>(Arrays.asList(
                            "Chức năng\nPha lê",
                            "Nâng cấp\nTrang bị",
                            "Võ đài\nSinh Tử",
//                            "Map địa\nngục",
                            // Da bo "Nang cap de Tu": de tu gio khong nang cap
                            // duoc nua, chi khac nhau o LOAI nhan tu trung.
                            //
                            // "Chuc nang khac" tam bo, thay bang thang muc hay
                            // dung nhat trong do la Tinh an trang bi.
                            "Tinh ấn\ntrang bị"
                    ));


                    this.createOtherMenu(player, ConstNpc.BASE_MENU, "Ngươi tìm ta có việc gì?", menuOptions.toArray(String[]::new));
                    break;
                case 112: {
                    if (Util.isAfterMidnight(player.lastTimePKVoDaiSinhTu)) {
                        player.haveRewardVDST = false;
                        player.thoiVangVoDaiSinhTu = 0;
                    }
                    if (player.haveRewardVDST) {
                        this.createOtherMenu(player, ConstNpc.BASE_MENU, "Đây là phần thưởng cho con.", "1 ngọc bí\nbất kì", "1 bí ngô");
                        return;
                    }
                    if (DeathOrAliveArenaManager.gI().getVDST(player.zone) != null) {
                        if (DeathOrAliveArenaManager.gI().getVDST(player.zone).getPlayer().equals(player)) {
                            this.createOtherMenu(player, ConstNpc.BASE_MENU, "Ngươi muốn hủy đăng ký thi đấu võ đài?", "Top 100", "Đồng ý\n" + player.thoiVangVoDaiSinhTu + " thỏi vàng", "Từ chối", "Về\nđảo rùa");
                            return;
                        }
                        this.createOtherMenu(player, ConstNpc.BASE_MENU, "Ngươi muốn đăng ký thi đấu võ đài?\nnhiều phần thưởng giá trị đang đợi ngươi đó", "Top 100", "Bình chọn", "Đồng ý\n" + player.thoiVangVoDaiSinhTu + " thỏi vàng", "Từ chối", "Về\nđảo rùa");
                        return;
                    }
                    this.createOtherMenu(player, ConstNpc.BASE_MENU, "Ngươi muốn đăng ký thi đấu võ đài?\nnhiều phần thưởng giá trị đang đợi ngươi đó",
                            "Top 100", "Đồng ý\n" + player.thoiVangVoDaiSinhTu + " thỏi vàng", "Từ chối", "Về\nđảo rùa");
                    break;
                }
                case 174:
                    this.createOtherMenu(player, ConstNpc.BASE_MENU, "Ngươi tìm ta có việc gì?", "Quay về", "Từ chối");
                    break;
                case 181:
                    this.createOtherMenu(player, ConstNpc.BASE_MENU, "Ngươi tìm ta có việc gì?", "Quay về", "Từ chối");
                    break;
                default: {
                    List<String> menu = new ArrayList<>(Arrays.asList(
                            "Sách\nTuyệt Kỹ",
                            "Cửa hàng\nBùa",
                            "Nâng cấp\nVật phẩm",
                            "Làm phép\nNhập đá",
                            "Nhập\nNgọc Rồng"
                          
                    ));

                    // Nếu có bất kỳ BT1/2/3 thì chèn "Bông tai Porata" vào slot 4 (index 3)
                    if (InventoryService.gI().findItem(player, 454) // BT1
                            || InventoryService.gI().findItem(player, 921) // BT2
                            || InventoryService.gI().findItem(player, 1943)) { // BT3
                        menu.add(3, "Bông tai\nPorata"); // ĐẢM BẢO Ô SỐ 4 LUÔN LÀ BÔNG TAI
                    }

                    if (DailyGiftService.checkDailyGift(player, ConstDailyGift.NHAN_BUA_MIEN_PHI)) {
                        menu.add(0, "Thưởng\nBùa 1h\nngẫu nhiên");
                    }

                    String[] menus = menu.toArray(new String[0]);
                    this.createOtherMenu(player, ConstNpc.BASE_MENU, "Ngươi tìm ta có việc gì?", menus);
                    break;
                }

            }
        }
    }

    @Override
    public void confirmMenu(Player player, int select) {
        if (canOpenNpc(player)) {
            switch (this.mapId) {
                case 5: {
                    switch (player.iDMark.getIndexMenu()) {
                        case ConstNpc.BASE_MENU: {
                            switch (select) {
                                case 0:
                                    createOtherMenu(player, ConstMenu.MENU_PHA_LE, "Ta có thể giúp gì cho ngươi ?",
                                            "Ép sao\ntrang bị", "Pha lê\nhoá\ntrang bị"
//                                            , "Nâng cấp\nSao pha lê", "Đánh bóng\nSao pha lê", "Cường hoá\nLỗ sao\npha lê", "Tạo đá Hematite"
                                    );
                                    break;
                                case 1://Chuyển hoá trang bị
                                    createOtherMenu(player, ConstMenu.MENU_NANG_CAP_TRANG_BI, "Ta sẽ biến trang bị của ngươi thành trang bị Kích Hoạt",
                                            "Nâng đồ Hủy diệt","Kích hoạt\nThường", "Kích hoạt\nVIP");
                                    break;
                                case 2:
                                    ChangeMapService.gI().changeMapNonSpaceship(player, 112, 200 + Util.nextInt(-100, 100), 408);
                                    break;
//                                case 3:
//                                    ChangeMapService.gI().changeMapNonSpaceship(player, 167, 200 + Util.nextInt(-100, 100), 408);
//                                    break;
                                // Muc thu tu gio la Tinh an trang bi, mo thang
                                // tab ghep chu khong qua menu con nua.
                                case 3:
                                    CombineService.gI().openTabCombine(player, CombineService.AN_TRANG_BI);
                                    break;
                                // Menu con "Chuc nang khac" giu lai nhung khong
                                // co duong nao mo tu day nua — de danh cho lan
                                // sau muon bat lai.
                                case 99:
                                    createOtherMenu(player, ConstMenu.CHUC_NANG_BHM_KHAC, "Ngươi tìm ta có việc gì?\n",
                                            //"Đập đồ\nẢo Hóa",
                                            "Build Đồ",
                                            "Pháp sư hoá",
                                            "Siêu hóa\n Cải trang",
                                            "Tinh ấn\ntrang bị",
//                                            "Tinh thạch\ntrang bị",
                                            "Nâng cấp\nGiáp LT"
                                    );
                                    break;
                                case 5:
                                    break;
                            }
                            break;
                        }
                        case ConstMenu.CHUC_NANG_BHM_KHAC: {
                            switch (select) {
//                                case 0:
//                                    CombineService.gI().openTabCombine(player, CombineService.DAP_DO_AO_HOA);
//                                    break;
                                case 0:
                                    this.createOtherMenu(player, ConstMenu.BUILD_DO_BHM, "|7|\bChi Tiết:\n|0|"
                                            + "\nMở Khóa GD: tỉ lệ thành công 30%"
                                            + "\nGia hạn Vật Phẩm: tỉ lệ thành công 30% + 3 - 7 ngày, 70% + 1 ngày"
                                            + "\nTẩy đồ: tẩy sao pha lê, chỉ số đặc biệt một số trang bị",
//                                            "Mở Khóa GD",
                                            "Gia hạn\n Vật Phẩm" ,
                                            "Tẩy Đồ"
                                    );
                                    break;
                                case 1:
                                    CombineService.gI().openTabCombine(player, CombineService.PS_HOA_TRANG_BI);
                                    break;
                                case 2:
                                    CombineService.gI().openTabCombine(player, CombineService.SIEU_HOA);
                                    break;
                                case 3:
                                    CombineService.gI().openTabCombine(player, CombineService.AN_TRANG_BI);
                                    break;
//                                case 4:
//                                    CombineService.gI().openTabCombine(player, CombineService.TINH_THACH_HOA);
//                                    break;
                                case 4:
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_GIAP_LUYEN_TAP);
                                    break;
                            }
                            break;
                        }
                        case ConstMenu.BUILD_DO_BHM: {
                            switch (select) {
//                                case 0: //Mở khóa Item
//                                    CombineService.gI().openTabCombine(player, CombineService.MO_KHOA_ITEM);
//                                    break;
                                case 0: //Gia hạn vật phẩm
                                    CombineService.gI().openTabCombine(player, CombineService.GIA_HAN_VAT_PHAM);
                                    break;
                                case 1: //Tẩy đồ
                                    CombineService.gI().openTabCombine(player, CombineService.TAY_PS_HOA_TRANG_BI);
                                    break;
                            }
                            break;
                        }
                        case ConstMenu.SHOP_BHM: {
                            switch (select) {
                                case 0:
                                    Service.gI().sendThongBao(player, "Chưa mở");
                                    break;
                                case 1:
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_CHAN_MENH);
                                    break;
                                case 2:
                                    ShopService.gI().opendShop(player, "SHOP_BHM", false);
                                    break;
                                case 3:
                                    ShopService.gI().opendShop(player, "SHOP_THOI_BHM", false);
                                    break;
                            }
                            break;
                        }
                        case ConstMenu.MENU_PHA_LE: {
                            switch (select) {
                                case 0: //Ép sao trang bị
                                    CombineService.gI().openTabCombine(player, CombineService.EP_SAO_TRANG_BI);
                                    break;
                                case 1: //Pha lê hoá trang bị
                                    createOtherMenu(player, ConstMenu.MENU_PHA_LE_HOA_TRANG_BI, "Ngươi muốn pha lê hoá trang bị bằng cách nào?", "Bằng ngọc", "Từ chối");
                                    break;
                                case 2: //Nâng cấp sao pha lê
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_SAO_PHA_LE);
                                    break;
                                case 3: //Đánh bóng sao pha lê
                                    CombineService.gI().openTabCombine(player, CombineService.DANH_BONG_SAO_PHA_LE);
                                    break;
                                case 4: //Cường hoá lỗ sao pha lê
                                    CombineService.gI().openTabCombine(player, CombineService.CUONG_HOA_LO_SAO_PHA_LE);
                                    break;
                                case 5: //Tạo đá Hematite
                                    CombineService.gI().openTabCombine(player, CombineService.TAO_DA_HEMATITE);
                                    break;
                            }
                            break;
                        }
                        case ConstMenu.MENU_NANG_CAP_TRANG_BI: {
                            switch (select) {
                                case 0:
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_DO_HD);
                                    break;
                                case 1:
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_KICH_HOAT);
                                    break;
                                case 2:
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_KICH_HOAT_VIP);
                                    break;
                            }
                            break;
                        }
                        case ConstMenu.MENU_CHUYEN_HOA_TRANG_BI: {
                            switch (select) {
                                case 0: {
                                    CombineService.gI().openTabCombine(player, CombineService.CHUYEN_HOA_TRANG_BI_DUNG_VANG);
                                    break;
                                }
                                case 1: {
                                    CombineService.gI().openTabCombine(player, CombineService.CHUYEN_HOA_TRANG_BI_DUNG_NGOC);
                                    break;
                                }
                            }
                            break;
                        }
                        case ConstMenu.MENU_PHA_LE_HOA_TRANG_BI: {
                            if (select == 0) {
                                CombineService.gI().openTabCombine(player, CombineService.PHA_LE_HOA_TRANG_BI);
                            }
                            break;
                        }
                        case ConstNpc.MENU_START_COMBINE: {
                            switch (player.combine.typeCombine) {
                                case CombineService.PHA_LE_HOA_TRANG_BI: {
                                    switch (select) {
                                        case 0:
                                            CombineService.gI().startCombine(player, 100);
                                            break;
                                        case 1:
                                            CombineService.gI().startCombine(player, 10);
                                            break;
                                        case 2:
                                            CombineService.gI().startCombine(player);
                                            break;
                                    }
                                    break;
                                }

                                case CombineService.NANG_CAP_KICH_HOAT_VIP:
                                case CombineService.NANG_CAP_KICH_HOAT:
                                // Tach rieng vi menu cua no co ba muc:
                                // "Lam phep", "Lam den khi duoc", "Tu choi".
                                // De trong khoi dung chung thi muc thu hai roi
                                // vao case 1 khong ai xu ly -> bam vao im lang.
                                case CombineService.NANG_CAP_SAO_PHA_LE: {
                                    switch (select) {
                                        case 0:
                                            CombineService.gI().startCombine(player);
                                            break;
                                        case 1:
                                            nro.entity.combine.list.NangCapSaoPhaLe
                                                    .lamDenKhiDuoc(player);
                                            break;
                                        default:
                                            break;
                                    }
                                    break;
                                }
                                case CombineService.DANH_BONG_SAO_PHA_LE:
                                case CombineService.CUONG_HOA_LO_SAO_PHA_LE:
                                case CombineService.TAO_DA_HEMATITE:
                                case CombineService.EP_SAO_TRANG_BI:
                                case CombineService.DAP_DO_AO_HOA:
                                case CombineService.PS_HOA_TRANG_BI:
                                case CombineService.TAY_PS_HOA_TRANG_BI:
                                case CombineService.SIEU_HOA:
                                case CombineService.AN_TRANG_BI:
                                case CombineService.TINH_THACH_HOA:
                                case CombineService.NANG_GIAP_LUYEN_TAP:
                                case CombineService.MO_KHOA_ITEM:
                                case CombineService.GIA_HAN_VAT_PHAM:
                                case CombineService.NANG_CAP_CHAN_MENH:
                                case CombineService.NANG_CAP_DE_TU:
                                case CombineService.NANG_CAP_DO_HD:{

                                    switch (select) {
                                        case 0:
                                            CombineService.gI().startCombine(player);
                                            break;
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    break;
                }
                case 112: {
                    if (player.iDMark.isBaseMenu()) {
                        if (player.haveRewardVDST) {
                            switch (select) {
                                case 0: {
                                    if (InventoryService.gI().getCountEmptyBag(player) > 0) {
                                        Item item = ItemService.gI().createNewItem((short) (Util.nextInt(705, 708)));
                                        item.addOptionParam(93, 30);
                                        InventoryService.gI().addItemBag(player, item);
                                        InventoryService.gI().sendItemBag(player);
                                        Service.gI().sendThongBao(player, "Bạn nhận được " + item.template.name);
                                        player.haveRewardVDST = false;
                                    } else {
                                        Service.gI().sendThongBao(player, "Hành trang không còn chỗ trống, không thể nhặt thêm");
                                    }
                                    break;
                                }
                                case 1: {
                                    if (InventoryService.gI().getCountEmptyBag(player) > 0) {
                                        Item item = ItemService.gI().createNewItem((short) 585);
                                        item.addOptionParam(93, 30);
                                        InventoryService.gI().addItemBag(player, item);
                                        InventoryService.gI().sendItemBag(player);
                                        Service.gI().sendThongBao(player, "Bạn nhận được " + item.template.name);
                                        player.haveRewardVDST = false;
                                    } else {
                                        Service.gI().sendThongBao(player, "Hành trang không còn chỗ trống, không thể nhặt thêm");
                                    }
                                    break;
                                }
                            }
                            return;
                        }
                        if (DeathOrAliveArenaManager.gI().getVDST(player.zone) != null) {
                            if (DeathOrAliveArenaManager.gI().getVDST(player.zone).getPlayer().equals(player)) {
                                switch (select) {
                                    case 0: {
//                                        TopService.showListTop(player, 5);
                                        break;
                                    }
                                    case 1:
                                        this.npcChat("Không thể thực hiện");
                                        break;
                                    case 2: {
                                        break;
                                    }
                                    case 3:
                                        ChangeMapService.gI().changeMapBySpaceShip(player, 5, -1, 1156);
                                        break;
                                }
                                return;
                            }
                            switch (select) {
                                case 0: {
//                                    TopService.showListTop(player, 5);
                                    break;
                                }
                                case 1:
                                    this.createOtherMenu(player, ConstNpc.DAT_CUOC_HAT_MIT, "Phí bình chọn là 1 triệu vàng\nkhi trận đấu kết thúc\n90% tổng tiền bình chọn sẽ chia đều cho phe bình chọn chính xác", "Bình chọn cho " + DeathOrAliveArenaManager.gI().getVDST(player.zone).getPlayer().name + " (" + DeathOrAliveArenaManager.gI().getVDST(player.zone).getCuocPlayer() + ")", "Bình chọn cho hạt mít (" + DeathOrAliveArenaManager.gI().getVDST(player.zone).getCuocBaHatMit() + ")");
                                    break;
                                case 2:
                                    DeathOrAliveArenaService.gI().startChallenge(player);
                                    break;
                                case 3: {
                                    break;
                                }
                                case 4:
                                    ChangeMapService.gI().changeMapBySpaceShip(player, 5, -1, 1156);
                                    break;
                            }
                            return;
                        }
                        switch (select) {
                            case 0: {
//                                TopService.showListTop(player, 5);
                                break;
                            }
                            case 1:
                                DeathOrAliveArenaService.gI().startChallenge(player);
                                break;
                            case 2: {
                                break;
                            }
                            case 3:
                                ChangeMapService.gI().changeMapBySpaceShip(player, 5, -1, 1156);
                                break;
                        }
                    } else if (player.iDMark.getIndexMenu() == ConstNpc.DAT_CUOC_HAT_MIT) {
                        if (DeathOrAliveArenaManager.gI().getVDST(player.zone) != null) {
                            switch (select) {
                                case 0: {
                                    if (player.inventory.gold >= 1_000_000) {
                                        DeathOrAliveArena vdst = DeathOrAliveArenaManager.gI().getVDST(player.zone);
                                        vdst.setCuocPlayer(vdst.getCuocPlayer() + 1);
                                        vdst.addBinhChon(player);
                                        player.binhChonPlayer++;
                                        player.zoneBinhChon = player.zone;
                                        player.inventory.gold -= 1_000_000;
                                        Service.gI().sendMoney(player);
                                    } else {
                                        Service.gI().sendThongBao(player, "Bạn không đủ vàng, còn thiếu " + Util.formatNumber(1_000_000 - player.inventory.gold, FormatStyle.VIETNAMESE) + " vàng nữa");
                                    }
                                    break;
                                }
                                case 1: {
                                    if (player.inventory.gold >= 1_000_000) {
                                        DeathOrAliveArena vdst = DeathOrAliveArenaManager.gI().getVDST(player.zone);
                                        vdst.setCuocBaHatMit(vdst.getCuocBaHatMit() + 1);
                                        vdst.addBinhChon(player);
                                        player.binhChonHatMit++;
                                        player.zoneBinhChon = player.zone;
                                        player.inventory.gold -= 1_000_000;
                                        Service.gI().sendMoney(player);
                                    } else {
                                        Service.gI().sendThongBao(player, "Bạn không đủ vàng, còn thiếu " + Util.formatNumber(1_000_000 - player.inventory.gold, FormatStyle.VIETNAMESE) + " vàng nữa");
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    break;
                }
                case 174:
                case 181: {
                    if (player.iDMark.isBaseMenu()) {
                        switch (select) {
                            case 0:
                                ChangeMapService.gI().changeMapBySpaceShip(player, 5, -1, 1156);
                                break;
                        }
                    }
                    break;
                }
                // MỌI bản đồ còn lại, không phải bốn số đếm tay.
                //
                // Trước đây nhánh này viết là `case 42/43/44/84`, trong khi
                // openBaseMenu lại dựng menu ở nhánh `default` — tức là ở BẤT KỲ
                // bản đồ nào khác 5/112/174/181. Hai bên lệch nhau: bản đồ nào
                // có Bà Hạt Mít mà không nằm trong bốn số kia thì menu vẫn hiện
                // ra đủ mục, bấm vào thì KHÔNG có gì xảy ra — không báo lỗi,
                // không đóng menu.
                //
                // Hiện Bà Hạt Mít đứng ở ba vách núi của ba hành tinh: bản đồ
                // 42, 43, 44. Nhưng chỗ đặt NPC nằm trong cột `npcs` của bảng
                // map_template chứ không nằm trong mã — thêm một bà nữa ở bản đồ
                // khác là chuyện sửa cơ sở dữ liệu, không ai nhớ phải quay lại
                // sửa cả file này. Để `default` thì hai hàm khớp nhau theo định
                // nghĩa, đặt NPC ở đâu cũng chạy.
                default: {
                    if (player.iDMark.isBaseMenu()) {
                        if (!DailyGiftService.checkDailyGift(player, ConstDailyGift.NHAN_BUA_MIEN_PHI)) {
                            select++;
                        }
                        if (!InventoryService.gI().findItem(player, 454) // BT1
                                && !InventoryService.gI().findItem(player, 921) // BT2
                                && !InventoryService.gI().findItem(player, 1943)) {  // BT3
                            if (select >= 4) {
                                select++;
                            }
                        }

                        switch (select) {
                            case 0:
                                if (DailyGiftService.checkDailyGift(player, ConstDailyGift.NHAN_BUA_MIEN_PHI)) {
                                    int idItem = Util.nextInt(213, 219);
                                    player.charms.addTimeCharms(idItem, 60);
                                    Item bua = ItemService.gI().createNewItem((short) idItem);
                                    Service.gI().sendThongBao(player, "Bạn vừa nhận thưởng " + bua.template.name);
                                    DailyGiftService.updateDailyGift(player, ConstDailyGift.NHAN_BUA_MIEN_PHI);
                                } else {
                                    Service.gI().sendThongBao(player, "Hôm nay bạn đã nhận bùa miễn phí rồi!!!");
                                }
                                break;
                            case 1:
                                createOtherMenu(player, ConstNpc.MENU_SACH_TUYET_KY, "Ta có thể giúp gì cho ngươi ?",
                                        "Đóng thành\nSách cũ",
                                        "Đổi Sách\nTuyệt kỹ",
                                        "Giám định\nSách",
                                        "Tẩy\nSách",
                                        "Nâng cấp\nSách\nTuyệt kỹ",
                                        "Hồi phục\nSách",
                                        "Phân rã\nSách");
                                break;
                            case 2:
                                createOtherMenu(player, ConstNpc.MENU_OPTION_SHOP_BUA,
                                        loiChaoCuaHangBua(player),
                                        "Bùa\n(vĩnh viễn)",
                                        "Xoá bùa\n" + GIA_HOA_GIAI_BUA + " thỏi vàng",
                                        "Đóng");
                                break;
                            case 3:
                                CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_VAT_PHAM);
                                break;
                            case 4: { // Bông tai Porata
                                if (InventoryService.gI().findItem(player, 454)) {
                                    // Có BT1 -> mở tab nâng BT2
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_BONG_TAI);

                                } else if (InventoryService.gI().findItem(player, 921)) {
                                    // Có BT2 -> submenu cho 2 chức năng
                                    this.createOtherMenu(player, ConstMenu.MENU_BONG_TAI,
                                            "Ngươi muốn làm gì với Bông Tai [+2]?",
                                            "Nâng cấp lên BT3",
                                            "Mở chỉ số BT2",
                                            "Từ chối");

                                } else if (InventoryService.gI().findItem(player, 1943)) {
                                    // Có BT3 -> mở tab mở chỉ số BT3
                                    CombineService.gI().openTabCombine(player, CombineService.NANG_CHI_SO_BONG_TAI_3);
                                }
                                break;
                            }

                            case 5:
                                CombineService.gI().openTabCombine(player, CombineService.LAM_PHEP_NHAP_DA);
                                break;
                            case 6:
                                CombineService.gI().openTabCombine(player, CombineService.NHAP_NGOC_RONG);
                                break;
                        }
                    } else if (player.iDMark.getIndexMenu() == ConstNpc.MENU_SACH_TUYET_KY) {
                        switch (select) {
                            case 0:
                                CheTaoCuonSachCu.showCombine(player);
                                break;
                            case 1:
                                DoiSachTuyetKy.showCombine(player);
                                break;
                            case 2:
                                CombineService.gI().openTabCombine(player, CombineService.GIAM_DINH_SACH);
                                break;
                            case 3:
                                CombineService.gI().openTabCombine(player, CombineService.TAY_SACH);
                                break;
                            case 4:
                                CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_SACH_TUYET_KY);
                                break;
                            case 5:
                                CombineService.gI().openTabCombine(player, CombineService.HOI_PHUC_SACH);
                                break;
                            case 6:
                                CombineService.gI().openTabCombine(player, CombineService.PHAN_RA_SACH);
                                break;
                        }
                    } else if (player.iDMark.getIndexMenu() == ConstMenu.MENU_BONG_TAI) {
                        // Submenu cho Bông Tai [+2]
                        switch (select) {
                            case 0: // Nâng BT3
                                CombineService.gI().openTabCombine(player, CombineService.NANG_CAP_BONG_TAI);
                                break;
                            case 1: // Mở chỉ số BT2
                                CombineService.gI().openTabCombine(player, CombineService.NANG_CHI_SO_BONG_TAI);
                                break;
                            default:
                                // Từ chối / đóng
                                break;
                        }
                    } else if (player.iDMark.getIndexMenu() == ConstNpc.DONG_THANH_SACH_CU) {
                        CheTaoCuonSachCu.cheTaoCuonSachCu(player);
                    } else if (player.iDMark.getIndexMenu() == ConstNpc.DOI_SACH_TUYET_KY) {
                        DoiSachTuyetKy.doiSachTuyetKy(player);
                    } else if (player.iDMark.getIndexMenu() == ConstNpc.MENU_OPTION_SHOP_BUA) {
                        switch (select) {
                            case 0:
                                muaFullBuaVinhVien(player);
                                break;
                            case 1:
                                // Hỏi lại trước khi xoá.
                                //
                                // Xoá bùa là việc KHÔNG lấy lại được, mà nút xoá
                                // lại nằm ngay cạnh nút mua — bấm nhầm một ô là
                                // mất sạch, kể cả bùa vĩnh viễn vừa mua bằng
                                // tiền thật. Một lần hỏi lại là đủ để không ai
                                // mất oan, mà người thực sự muốn xoá cũng chỉ
                                // tốn thêm một cái bấm.
                                createOtherMenu(player, ConstNpc.MENU_XAC_NHAN_XOA_BUA,
                                        "Hoá giải hết " + GIA_HOA_GIAI_BUA
                                        + " thỏi vàng. Mất sạch, kể cả bùa vĩnh"
                                        + " viễn, và ta KHÔNG hoàn lại tiền mua"
                                        + " bùa đâu. Ngươi chắc chưa?",
                                        "Xoá\nthật",
                                        "Thôi");
                                break;
                            default:
                                // "Đóng" — không làm gì.
                                break;
                        }
                    } else if (player.iDMark.getIndexMenu() == ConstNpc.MENU_XAC_NHAN_XOA_BUA) {
                        if (select == 0) {
                            // Tra tien TRUOC khi xoa.
                            //
                            // truThoiVang() kiem tra du hay khong roi moi tru, va
                            // tra false neu thieu — nguoi choi khong mat gi. Dat
                            // truoc resetAllCharms() thi khong co canh "bua da
                            // bay ma tien khong tru duoc".
                            if (ShopService.gI().truThoiVang(player, GIA_HOA_GIAI_BUA)) {
                                player.charms.resetAllCharms();
                                Service.gI().sendThongBao(player,
                                        "Đã hoá giải sạch bùa trong người.");
                            }
                        }
                    } else if (player.iDMark.getIndexMenu() == ConstNpc.MENU_START_COMBINE) {
                        switch (player.combine.typeCombine) {
                            case CombineService.NANG_CAP_BONG_TAI:
                            case CombineService.NANG_CHI_SO_BONG_TAI:
                            case CombineService.NANG_CHI_SO_BONG_TAI_3: // ✅ mở chỉ số BT3
                            case CombineService.LAM_PHEP_NHAP_DA:
//                            case CombineService.NHAP_NGOC_RONG:
                            case CombineService.GIAM_DINH_SACH:
                            case CombineService.TAY_SACH:
                            case CombineService.NANG_CAP_SACH_TUYET_KY:
                            case CombineService.HOI_PHUC_SACH: {
                                // Nhóm này chỉ có một nút "Làm phép" ở ô đầu.
                                if (select == 0) {
                                    CombineService.gI().startCombine(player);
                                }
                                break;
                            }
                            case CombineService.NHAP_NGOC_RONG: {
                                // Tách riêng khỏi nhóm trên: menu của nó có sáu ô
                                // với ý nghĩa khác hẳn, để chung một khối thì
                                // "Nhập x10" của bảng này lại là "Làm phép" của
                                // bảng kia và ngược lại.
                                int soLan;
                                switch (select) {
                                    case NhapNgocRong.CHON_X1:
                                        soLan = 1;
                                        break;
                                    case NhapNgocRong.CHON_X10:
                                        soLan = 10;
                                        break;
                                    case NhapNgocRong.CHON_X100:
                                        soLan = 100;
                                        break;
                                    case NhapNgocRong.CHON_HET:
                                        // Xin thật nhiều; hàm nhập tự hạ xuống
                                        // đúng số lần nguyên liệu cho phép.
                                        soLan = Integer.MAX_VALUE;
                                        break;
                                    case NhapNgocRong.CHON_SO_KHAC:
                                        NhapNgocRong.hoiSoLan(player);
                                        return;
                                    default:
                                        // "Từ chối"
                                        return;
                                }
                                NhapNgocRong.nhapNgocRong(player, soLan);
                                break;
                            }

                            case CombineService.PHAN_RA_SACH: {
                                if (select == 0) {
                                    CombineService.gI().startCombine(player);
                                }
                                break;
                            }
                            case CombineService.NANG_CAP_VAT_PHAM: {
                                if (select == 0) {
                                    CombineService.gI().startCombine(player);
                                } else if (select == 1) {
                                    NangCapVatPham.nangCapVatPham(player, true);
                                }
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
    }

    /**
     * Bán gói "Full bùa vĩnh viễn": trả tiền một lần, bảy lá bùa cơ bản không
     * bao giờ hết hạn nữa.
     *
     * <p>Giá lấy từ {@link ConfigDAO#BUA_VV_GIA_VANG} nên đổi được từ bảng
     * {@code panel_config} mà không phải biên dịch lại.</p>
     *
     * <p><b>Chặn mua lần hai.</b> Đã đủ bảy lá vĩnh viễn thì từ chối. Không có
     * cái này thì mỗi lần bấm là một lần trừ tiền mà chẳng thay đổi gì — bùa
     * đang vĩnh viễn rồi, gán lại vẫn vĩnh viễn.</p>
     */
    private void muaFullBuaVinhVien(Player player) {
        if (player.charms.daDuBuaVinhVien()) {
            Service.gI().sendThongBao(player,
                    "Ngươi đã có đủ bảy lá bùa vĩnh viễn rồi, mua thêm làm gì.");
            return;
        }
        long gia = ConfigDAO.num(ConfigDAO.BUA_VV_GIA_VANG, 500_000_000L);
        if (player.inventory.gold < gia) {
            Service.gI().sendThongBao(player, "Bạn không đủ vàng, còn thiếu "
                    + Util.formatNumber(gia - player.inventory.gold, FormatStyle.VIETNAMESE)
                    + " vàng nữa");
            return;
        }
        player.inventory.gold -= gia;
        player.charms.datVinhVienGoiBua();
        Service.gI().sendMoney(player);
        Service.gI().sendThongBao(player,
                "Xong! Bảy lá bùa của ngươi từ giờ vĩnh viễn không hết hạn.");
    }

    /**
     * Lời của Bà Hạt Mít ở cửa hàng bùa: liệt kê luôn bùa đang mang.
     *
     * <h2>Vì sao nhét danh sách vào đây</h2>
     *
     * <p>Cửa hàng chỉ còn hai mục — mua và xoá — nên không còn chỗ nào cho một
     * mục "xem bùa đang có". Mà người chơi <b>cần</b> thấy nó: nút "Xoá bùa"
     * nằm ngay cạnh nút mua, và xoá thì không lấy lại được. Biết mình đang có
     * gì trước khi bấm là chuyện tối thiểu.</p>
     *
     * <p>Khung lời thoại của NPC vốn để trống ba phần tư, nên danh sách nằm ở
     * đó không tốn thêm một cái bấm nào.</p>
     *
     * <p>Đếm đúng trọn gói ({@link Charms#GOI_VINH_VIEN}) — đúng bộ mà cửa
     * hàng này bán. Tên bùa đọc từ {@code ItemTemplate} chứ không viết cứng, để
     * đổi tên trong bảng {@code item_template} là hiện đúng ngay.</p>
     */
    private String loiChaoCuaHangBua(Player player) {
        long now = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder();
        int dem = 0;
        for (int id : Charms.GOI_VINH_VIEN) {
            long han = player.charms.thoiHan(id);
            if (han <= now) {
                continue;
            }
            dem++;
            sb.append("\n").append(tenBua(id)).append(": ")
                    .append(Charms.laVinhVien(han)
                            ? "vĩnh viễn"
                            : Util.formatCountdown(han, true, true, true));
        }
        if (dem == 0) {
            return "Bùa của ta rất lợi hại, nhìn ngươi yếu đuối thế này, chắc"
                    + " muốn mua bùa để mạnh mẽ à. Mua một lần là xài mãi,"
                    + " không hết hạn bao giờ.";
        }
        return "Bùa ngươi đang mang:" + sb;
    }

    /** Tên hiển thị của một lá bùa, lấy từ bảng vật phẩm. */
    private String tenBua(int itemId) {
        try {
            return ItemService.gI().getTemplate(itemId).name;
        } catch (Exception ex) {
            // Bang item_template thieu dong -> van hien duoc danh sach, chi la
            // mot dong ghi id thay vi ten. Khong dang de sap ca bang vi mot ten.
            return "Bùa " + itemId;
        }
    }
}


