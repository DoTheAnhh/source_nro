package network;

import java.net.Socket;

import lombok.Setter;
import java.io.DataInputStream;
import java.io.IOException;
import network.interfaces.IMessageSendCollect;
import network.interfaces.ISession;
import network.io.Message;

/**
 * Thread <b>đọc</b> của một session — chân trái của tam giác Collector/QueueHandler/Sender.
 *
 * <p><b>Vai trò:</b> đọc byte từ socket cho tới khi dựng đủ một {@link Message},
 * rồi <i>đẩy sang hàng đợi</i> chứ không xử lý. Nhờ tách như vậy, một gói tin
 * nghiệp vụ chạy chậm không làm nghẽn việc đọc socket.</p>
 *
 * <p><b>Ngoại lệ duy nhất:</b> gói {@link CommandMessage#GET_SESSION_ID} được xử
 * lý ngay tại đây (bắt tay khoá), không bao giờ tới {@code Controller}.</p>
 *
 * <p><b>Đây cũng là nơi phát hiện client rớt.</b> Khi socket đứt,
 * {@code readMessage} ném ngoại lệ, vòng lặp thoát, và phần code sau vòng lặp
 * chạy dọn dẹp — báo {@code sessionDisconnect} rồi {@code disconnect()}.
 * Không có đường nào khác phát hiện rớt kết nối.</p>
 */
public final class Collector implements Runnable {

    /** Session sở hữu thread này. Bị gán {@code null} trong {@link #dispose()}. */
    private ISession session;

    /** Luồng đọc của socket. */
    private DataInputStream dis;

    /**
     * Codec giải mã. Cùng một đối tượng với bên {@link Sender} — xem
     * {@code Session.setSendCollect}.
     */
    @Setter
    private IMessageSendCollect collect;

    /** Tạo collector và mở luồng đọc từ socket. */
    public Collector(ISession session, Socket socket) {
        this.session = session;
        this.setSocket(socket);
    }

    /**
     * Gắn (hoặc thay) socket và mở lại luồng đọc.
     *
     * <p>Trả về {@code this} để gọi nối chuỗi trong constructor của {@code Session}.
     * Lỗi mở luồng bị nuốt, khi đó {@code dis} còn {@code null} và
     * {@link #run()} sẽ thoát ngay ở vòng đầu.</p>
     */
    public Collector setSocket(Socket socket) {
        try {
            dis = new DataInputStream(socket.getInputStream());
        } catch (IOException ignored) {
        }
        return this;
    }

    /**
     * Vòng đọc chính. Chạy tới khi session ngắt hoặc socket lỗi.
     *
     * <p><b>Không có {@code sleep}</b> — {@code readMessage} tự chặn cho tới khi có
     * byte, nên vòng lặp này không quay không tải CPU.</p>
     *
     * <p>Nhánh {@code GET_SESSION_ID} rẽ theo vai của session:</p>
     * <ul>
     *   <li>{@code SERVER} — {@code sendKey()}: server gửi khoá xuống client.</li>
     *   <li>{@code CLIENT} — {@code setKey(msg)}: đọc khoá server gửi lên.</li>
     * </ul>
     *
     * <p>Mọi gói tin khác đi vào {@code queueHandler.addMessage(msg)} và được
     * thread {@link QueueHandler} xử lý.</p>
     *
     * <p><b>Nợ kỹ thuật:</b> hai khối {@code catch (Exception ignored)} rỗng gộp
     * chung mọi thứ — rớt mạng bình thường và bug thật (NPE, lỗi giải mã) trông
     * y hệt nhau và đều biến mất không dấu vết.</p>
     */
    @Override
    public void run() {
        try {
            while (session != null && session.isConnected()) {
                final Message msg = this.collect.readMessage(this.session, this.dis);
                if (msg.command == CommandMessage.GET_SESSION_ID) {
                    if (session.getSocketType() == SocketType.SERVER) {
                        this.session.sendKey();
                    } else {
                        this.session.setKey(msg);
                    }
                    msg.cleanup();
                } else {
                    this.session.getQueueHandler().addMessage(msg);
                }
            }
        } catch (Exception ignored) {
        }
        try {
            Network.gI().getAcceptHandler().sessionDisconnect(session);
        } catch (Exception ignored) {
        }
        if (this.session != null) {
            this.session.disconnect();
        }
    }

    /** Đóng luồng đọc. Việc này làm {@code readMessage} đang chặn bật ra ngay. */
    public void close() {
        if (dis != null) {
            try {
                dis.close();
            } catch (IOException ignored) {
            }
        }
    }

    /** Xoá mọi tham chiếu để GC thu hồi. Gọi sau {@link #close()}. */
    public void dispose() {
        session = null;
        dis = null;
        collect = null;
    }
}
