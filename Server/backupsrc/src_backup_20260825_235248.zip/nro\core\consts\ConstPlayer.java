package nro.core.consts;


public class ConstPlayer {
    
    public static final int[] HEADMONKEY = {192, 195, 196, 199, 197, 200, 198};
    public static final int[] DUOIHEADMONKEY = {192, 195, 196, 199, 197, 200, 198};

    public static final byte TRAI_DAT = 0;
    public static final byte NAMEC = 1;
    public static final byte XAYDA = 2;

    //type pk
    public static final byte NON_PK = 0;
    public static final byte PK_PVP = 3;
    public static final byte PK_PVP_2 = 4;
    public static final byte PK_ALL = 5;

    //type fushion
    public static final byte NON_FUSION = 0;
    public static final byte LUONG_LONG_NHAT_THE = 4;
    public static final byte HOP_THE_PORATA = 6;
    public static final byte HOP_THE_PORATA2 = 8;
    public static final byte HOP_THE_PORATA3 = 10;
    public static final byte HOP_THE_PORATA4 = 12;
    public static final byte HOP_THE_PORATA5 = 14;
  
    //
    public static final int QTY_MAX_ITEM_BODY_PLAYER = 12;
    public static final int QTY_MAX_ITEM_BODY_PET = 7;
    public static final int QTY_MAX_SKILL_PET = 3;
    
    //
    //const skill player
    public static final int[] SKILL_TD = new int[]{0, 1, 6, 20, 10, 24, 19};
    public static final int[] SKILL_NAMEC = new int[]{17, 3, 12, 11, 18, 26, 19};
    /**
     * Bảy kỹ năng mọi nhân vật Xayda được cấp sẵn (điểm 0).
     *
     * <p>Trước đây ghi {@code 22} — đó là Thôi miên của TRÁI ĐẤT, Xayda không
     * có id này. Mỗi lần đăng nhập, vòng cấp kỹ năng trong {@code GodGK} tạo
     * một kỹ năng BÓNG: {@code createSkillLevel0(22)} dựng SkillTemplate rỗng
     * (tên null, maxPoint 0, không có cấp nào) rồi lưu vào cột
     * {@code player.skills}. Client nhận danh sách có mục trỏ vào một kỹ năng
     * không tồn tại thì hỏng cả bảng kỹ năng — bấm icon không chọn được chiêu
     * nào ngoài đòn đấm.
     *
     * <p>{@code 23} = Trói, kỹ năng khống chế của Xayda, đối ứng với Thôi miên
     * của Trái Đất. {@code SKILL_TD} và {@code SKILL_NAMEC} đều khớp bảng, chỉ
     * mảng này lệch.</p>
     */
    public static final int[] SKILL_XAYDA = new int[]{4, 5, 8, 13, 23, 25, 19};
}




