package nro.core.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import nro.core.log.Logger;

/**
 * Bảng định mức quy đổi tiền nạp ra vật phẩm.
 *
 * <p>Mỗi dòng nói: <i>bao nhiêu VNĐ đổi được 1 món của vật phẩm nào</i>.
 * Admin sửa trực tiếp trong panel quản trị, bấm Lưu là ghi xuống
 * {@value #FILE}.</p>
 *
 * <p><b>Vì sao để trong file chứ không nhúng trong code:</b> tỉ giá là thứ đổi
 * thường xuyên theo đợt khuyến mãi. Nhúng vào Java thì mỗi lần đổi giá phải sửa
 * mã nguồn và build lại cả server — đúng vấn đề đã ghi trong
 * docs/02-AUDIT-VAN-DE.md §B5.</p>
 *
 * <p>File hỏng hoặc chưa có thì trả về danh sách rỗng, không làm sập panel.</p>
 */
public class TopUpExchangeConfig {

    /** Nơi lưu bảng định mức. Cùng thư mục với các file cấu hình khác. */
    public static final String FILE = "data/config/quy_doi_nap.json";

    /** Một dòng định mức. */
    public static final class Rule {

        /** Id vật phẩm sẽ trao. */
        public int itemId;

        /** Số VNĐ đổi được <b>một</b> món. Phải &gt; 0. */
        public long vndPerUnit;

        /** Ghi chú tuỳ ý của admin, không ảnh hưởng tính toán. */
        public String note;

        public Rule() {
        }

        public Rule(int itemId, long vndPerUnit, String note) {
            this.itemId = itemId;
            this.vndPerUnit = vndPerUnit;
            this.note = note;
        }
    }

    private static final Type LIST_TYPE = new TypeToken<List<Rule>>() {
    }.getType();

    private TopUpExchangeConfig() {
    }

    /**
     * Đọc bảng định mức từ đĩa.
     *
     * @return danh sách sửa được; rỗng nếu chưa có file hoặc file hỏng
     */
    public static List<Rule> load() {
        File f = new File(FILE);
        if (!f.isFile()) {
            return new ArrayList<>();
        }
        try (FileReader r = new FileReader(f)) {
            List<Rule> list = new Gson().fromJson(r, LIST_TYPE);
            if (list == null) {
                return new ArrayList<>();
            }
            // Bỏ dòng vô nghĩa ngay lúc đọc: định mức <= 0 sẽ gây chia cho 0
            // ở chỗ tính số lượng.
            List<Rule> ok = new ArrayList<>();
            for (Rule x : list) {
                if (x != null && x.vndPerUnit > 0) {
                    ok.add(x);
                }
            }
            return ok;
        } catch (Exception ex) {
            Logger.logException(TopUpExchangeConfig.class, ex,
                    "Không đọc được " + FILE + " — dùng bảng rỗng");
            return new ArrayList<>();
        }
    }

    /**
     * Ghi bảng định mức xuống đĩa.
     *
     * @return {@code true} nếu ghi thành công
     */
    public static boolean save(List<Rule> rules) {
        File f = new File(FILE);
        File dir = f.getParentFile();
        if (dir != null && !dir.isDirectory() && !dir.mkdirs()) {
            Logger.err("CONFIG", "Không tạo được thư mục " + dir);
            return false;
        }
        try (FileWriter w = new FileWriter(f)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(rules, LIST_TYPE, w);
            return true;
        } catch (Exception ex) {
            Logger.logException(TopUpExchangeConfig.class, ex, "Không ghi được " + FILE);
            return false;
        }
    }
}
