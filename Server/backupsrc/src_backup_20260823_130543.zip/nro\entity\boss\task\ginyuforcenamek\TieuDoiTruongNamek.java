package nro.entity.boss.task.ginyuforcenamek;

import nro.entity.player.Player;
import nro.entity.boss.Boss;
import nro.entity.boss.BossID;
import nro.entity.boss.BossStatus;
import nro.entity.boss.BossesData;
import nro.core.util.Util;
import nro.core.consts.ConstTaskBadges;
import java.util.List;
import nro.entity.item.ItemOption;
import nro.service.item.ItemService;
import nro.service.badges.BadgesTaskService;
import nro.entity.map.ItemMap;
import nro.service.Service;

public class TieuDoiTruongNamek extends Boss {

    private long st;

    public TieuDoiTruongNamek() throws Exception {
        super(BossID.TIEU_DOI_TRUONG_NAMEK, false, true, false, false, BossesData.TIEU_DOI_TRUONG_NAMEK);
    }

    @Override
    public void moveTo(int x, int y) {
        if (this.currentLevel == 1) {
            return;
        }
        super.moveTo(x, y);
    }

    @Override
    public void reward(Player plKill) {
        BadgesTaskService.updateCountBagesTask(plKill, ConstTaskBadges.TRUM_SAN_BOSS, 1);

        for (int i = 0; i < Util.nextInt(10); i++) {
            Service.gI().dropItemMap(this.zone, new ItemMap(zone, 861, 1,
                    this.location.x + i * Util.nextInt(-50, 50),
                    this.zone.map.yPhysicInTop(this.location.x, this.location.y - 24),
                    plKill.id));
        }

        short itTemp = 617;
        ItemMap it = new ItemMap(zone, itTemp, 1,
                this.location.x + Util.nextInt(-50, 50),
                this.zone.map.yPhysicInTop(this.location.x, this.location.y - 24),
                plKill.id);

        // Lấy option mặc định từ shop
        List<ItemOption> ops = ItemService.gI().getListOptionItemShop(itTemp);

        if (!ops.isEmpty()) {
            it.options = ops;
        }

        // Thêm option 93 với số ngày random 1 - 7
        int soNgay = Util.nextInt(1, 7);
        it.options.add(new ItemOption(93, soNgay));

        // Drop ra map
        Service.gI().dropItemMap(this.zone, it);
    }

    @Override
    protected void notifyJoinMap() {
        if (this.currentLevel == 1) {
            return;
        }
        super.notifyJoinMap();
    }

    @Override
    public void joinMap() {
        super.joinMap();
        st = System.currentTimeMillis();
    }

    @Override
    public void doneChatS() {
        this.changeStatus(BossStatus.AFK);
    }

    @Override
    public void autoLeaveMap() {
        if (Util.canDoWithTime(st, 900000)) {
            this.leaveMapNew();
        }
        if (this.zone != null && this.zone.getNumOfPlayers() > 0) {
            st = System.currentTimeMillis();
        }
    }
}