package nro.entity.template;
/**
 *
 * @author DoTheAnh
 */
public class PartDetail {
 
    public short iconId;

    public byte dx;

    public byte dy;

    public PartDetail(short iconId, byte dx, byte dy) {
        this.iconId = iconId;
        this.dx = dx;
        this.dy = dy;
    }
}






